
declare global {
	interface Window {
		a: number;
	}
}


export function foo() {
	return 'returned foo';
}