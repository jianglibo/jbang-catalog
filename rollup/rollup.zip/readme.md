## using tmux

| command | explain|
| ------  | -----  |
| tmux    | start tmux |
| Ctrl-b :| entry tmux command|
| Ctrl-b d| detach tmux session|

## start live-server

```bash
live-server --port=$TOBF_SERVER_PORT --no-browser
```

