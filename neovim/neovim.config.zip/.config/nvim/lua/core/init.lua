require('core/options')
require('core/autocmds')
